# Student Performance Prediction using Machine Learning

**Student:** Raval Harmi  
**Roll No.:** 535  
**Course:** SYBCA AI - Semester 3

## Project contents
- `Code/all code.py` — the project code based on the code supplied by the student.
- `Dataset/dataset.csv` — 1,000-row student performance dataset.
- `Graphs/` — analysis and model result graphs.
- `Reports/EDA_Report.html` — exploratory data analysis report.
- `Reports/model_comparison.csv` — Linear Regression and Ridge Regression results.
- `Model/student_performance_model.pkl` — saved trained Linear Regression model.
- `Student_Performance_Project_Report.pdf` — project report.

## Run in VS Code
1. Extract this ZIP file.
2. Open the extracted `Student_Performance_Prediction_Raval_Harmi_535` folder in VS Code.
3. Open Terminal → New Terminal.
4. Install libraries once: `python -m pip install -r requirements.txt`
5. Run: `python "Code/all code.py"`
6. When asked, enter study hours, attendance percentage, previous score, assignment score, extracurricular activity (Yes/No), and sleep hours.

If `python` is not recognized, try `py` in place of `python`.

## Important
The dataset is expected at `Dataset/dataset.csv`. Keep the folder structure unchanged. The code saves graphs and the trained model in this project folder.
