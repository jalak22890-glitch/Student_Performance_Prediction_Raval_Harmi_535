# ============================================================
# Student Performance Prediction using Machine Learning
# Roll No: 535
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from pathlib import Path

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import r2_score, mean_squared_error


# ============================================================
# 1. LOAD DATASET
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

# This file is stored in Code/, so parent.parent is the project root.
for folder_name in ["Graphs", "Reports", "Model"]:
    (BASE_DIR / folder_name).mkdir(parents=True, exist_ok=True)

dataset_path = BASE_DIR / "Dataset" / "dataset.csv"

print("Dataset path:", dataset_path)

df = pd.read_csv(dataset_path)

print("\n========================================")
print("STUDENT PERFORMANCE PREDICTION")
print("========================================")


# ============================================================
# 2. UNDERSTANDING DATA
# ============================================================

print("\nFirst 5 Records:")
print(df.head())

print("\nDataset Information:")
print(df.info())

print("\nDataset Shape:")
print(df.shape)

print("\nStatistical Summary:")
print(df.describe())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nDuplicate Values:")
print(df.duplicated().sum())


# ============================================================
# 3. DATA PREPROCESSING
# ============================================================

print("\n========================================")
print("DATA PREPROCESSING")
print("========================================")

# Remove duplicate rows
df = df.drop_duplicates()

# Convert Extracurricular Activity into 0 and 1
if "Extracurricular_Activity" in df.columns:

    df["Extracurricular_Activity"] = (
        df["Extracurricular_Activity"]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    df["Extracurricular_Activity"] = df[
        "Extracurricular_Activity"
    ].map({
        "yes": 1,
        "no": 0
    })


# Convert numeric columns
numeric_columns = [
    "Study_Hours",
    "Attendance",
    "Previous_Score",
    "Assignment_Score",
    "Extracurricular_Activity",
    "Sleep_Hours",
    "Final_Score"
]

for column in numeric_columns:

    if column in df.columns:
        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )


# Replace infinite values
df = df.replace(
    [np.inf, -np.inf],
    np.nan
)


# Fill missing numeric values with median
for column in numeric_columns:

    if column in df.columns:

        median_value = df[column].median()

        if pd.notna(median_value):
            df[column] = df[column].fillna(median_value)


print("\nMissing Values After Preprocessing:")
print(df.isnull().sum())


# ============================================================
# 4. EXPLORATORY DATA ANALYSIS
# ============================================================

print("\n========================================")
print("EXPLORATORY DATA ANALYSIS")
print("========================================")


# ------------------------------------------------------------
# Histogram
# ------------------------------------------------------------

plt.figure(figsize=(8, 5))

plt.hist(
    df["Final_Score"],
    bins=10,
    edgecolor="black"
)

plt.xlabel("Final Score")
plt.ylabel("Number of Students")
plt.title("Distribution of Final Scores")

plt.tight_layout()
plt.savefig(BASE_DIR / "Graphs" / "final_score_distribution.png", dpi=150, bbox_inches="tight")
plt.close()


# ------------------------------------------------------------
# Box Plot
# ------------------------------------------------------------

plt.figure(figsize=(8, 5))

plt.boxplot(df["Final_Score"])

plt.ylabel("Final Score")
plt.title("Box Plot of Final Scores")

plt.tight_layout()
plt.savefig(BASE_DIR / "Graphs" / "final_score_boxplot.png", dpi=150, bbox_inches="tight")
plt.close()


# ------------------------------------------------------------
# Pie Chart
# ------------------------------------------------------------

if "Extracurricular_Activity" in df.columns:

    activity_counts = df[
        "Extracurricular_Activity"
    ].value_counts()

    plt.figure(figsize=(7, 7))

    plt.pie(
        activity_counts,
        labels=activity_counts.index,
        autopct="%1.1f%%",
        startangle=90
    )

    plt.title(
        "Extracurricular Activity Distribution"
    )

    plt.tight_layout()
    plt.savefig(BASE_DIR / "Graphs" / "activity_pie.png", dpi=150, bbox_inches="tight")
    plt.close()


# ------------------------------------------------------------
# Bar Chart
# ------------------------------------------------------------

if "Extracurricular_Activity" in df.columns:

    avg_score = df.groupby(
        "Extracurricular_Activity"
    )["Final_Score"].mean()

    plt.figure(figsize=(8, 5))

    plt.bar(
        avg_score.index.astype(str),
        avg_score.values
    )

    plt.xlabel(
        "Extracurricular Activity (0 = No, 1 = Yes)"
    )

    plt.ylabel("Average Final Score")

    plt.title(
        "Average Final Score by Extracurricular Activity"
    )

    plt.tight_layout()
    plt.savefig(BASE_DIR / "Graphs" / "activity_average.png", dpi=150, bbox_inches="tight")
    plt.close()


# ------------------------------------------------------------
# Correlation Matrix
# ------------------------------------------------------------

numeric_df = df.select_dtypes(
    include=["number"]
)

plt.figure(figsize=(10, 7))

sns.heatmap(
    numeric_df.corr(),
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlation Matrix")

plt.tight_layout()
plt.savefig(BASE_DIR / "Graphs" / "correlation_matrix.png", dpi=150, bbox_inches="tight")
plt.close()


# ============================================================
# 5. AUTOMATED EDA REPORT
# ============================================================

print("\n========================================")
print("AUTOMATED EDA")
print("========================================")

try:

    from ydata_profiling import ProfileReport

    report_path = (
        BASE_DIR
        / "Reports"
        / "EDA_Report.html"
    )

    profile = ProfileReport(
        df,
        title="Student Performance EDA Report",
        explorative=True
    )

    profile.to_file(report_path)

    print(
        "\nEDA Report generated successfully!"
    )

    print(
        "Report saved at:",
        report_path
    )

except Exception as e:

    print(
        "\nAutomated EDA report could not be generated."
    )

    print("Error:", e)


# ============================================================
# 6. FEATURE SELECTION
# ============================================================

print("\n========================================")
print("FEATURE SELECTION")
print("========================================")


# Independent variables
features = [
    "Study_Hours",
    "Attendance",
    "Previous_Score",
    "Assignment_Score",
    "Extracurricular_Activity",
    "Sleep_Hours"
]

# Check available features
features = [
    column
    for column in features
    if column in df.columns
]

# Dependent variable
target = "Final_Score"


X = df[features].copy()

y = df[target].copy()


# Convert X to numeric
X = X.apply(
    pd.to_numeric,
    errors="coerce"
)

# Replace infinite values
X = X.replace(
    [np.inf, -np.inf],
    np.nan
)

# Fill missing X values
X = X.fillna(
    X.median()
)

X = X.fillna(0)


# Convert target to numeric
y = pd.to_numeric(
    y,
    errors="coerce"
)

y = y.replace(
    [np.inf, -np.inf],
    np.nan
)


# Remove rows where target is missing
valid_rows = y.notna()

X = X.loc[valid_rows]

y = y.loc[valid_rows]


print("\nIndependent Variables:")
print(features)

print("\nDependent Variable:")
print(target)

print("\nNaN values in X:")
print(X.isnull().sum().sum())

print("\nNaN values in y:")
print(y.isnull().sum())


# ============================================================
# 7. TRAIN TEST SPLIT
# ============================================================

print("\n========================================")
print("TRAIN TEST SPLIT")
print("========================================")


X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)


print(
    "\nTraining Data:",
    X_train.shape
)

print(
    "Testing Data:",
    X_test.shape
)


# ============================================================
# 8. LINEAR REGRESSION MODEL
# ============================================================

print("\n========================================")
print("LINEAR REGRESSION MODEL")
print("========================================")


model = LinearRegression()

model.fit(
    X_train,
    y_train
)


# Prediction
y_pred = model.predict(X_test)


print("\nModel trained successfully!")


# ============================================================
# 9. MODEL EVALUATION
# ============================================================

print("\n========================================")
print("MODEL EVALUATION")
print("========================================")


r2 = r2_score(
    y_test,
    y_pred
)

mse = mean_squared_error(
    y_test,
    y_pred
)

rmse = np.sqrt(mse)


print("\nR2 Score:")
print(round(r2, 4))

print("\nMean Squared Error:")
print(round(mse, 4))

print("\nRoot Mean Squared Error:")
print(round(rmse, 4))


# ============================================================
# 10. ACTUAL VS PREDICTED GRAPH
# ============================================================

plt.figure(figsize=(8, 5))

plt.scatter(
    y_test,
    y_pred
)

plt.xlabel("Actual Final Score")
plt.ylabel("Predicted Final Score")

plt.title(
    "Actual vs Predicted Final Score"
)

plt.tight_layout()
plt.savefig(BASE_DIR / "Graphs" / "actual_vs_predicted.png", dpi=150, bbox_inches="tight")
plt.close()


# ============================================================
# 11. CROSS VALIDATION
# ============================================================

print("\n========================================")
print("CROSS VALIDATION")
print("========================================")


cv_scores = cross_val_score(
    LinearRegression(),
    X,
    y,
    cv=5,
    scoring="r2"
)


print("\nCross Validation R2 Scores:")

for score in cv_scores:

    print(
        round(score, 4)
    )


print(
    "\nAverage Cross Validation R2:"
)

print(
    round(cv_scores.mean(), 4)
)


# ============================================================
# 12. RIDGE REGULARIZATION
# ============================================================

print("\n========================================")
print("RIDGE REGULARIZATION")
print("========================================")


ridge_model = Ridge(
    alpha=1.0
)

ridge_model.fit(
    X_train,
    y_train
)


ridge_pred = ridge_model.predict(
    X_test
)


ridge_r2 = r2_score(
    y_test,
    ridge_pred
)


ridge_mse = mean_squared_error(
    y_test,
    ridge_pred
)


ridge_rmse = np.sqrt(
    ridge_mse
)


print("\nRidge R2 Score:")
print(round(ridge_r2, 4))

print("\nRidge MSE:")
print(round(ridge_mse, 4))

print("\nRidge RMSE:")
print(round(ridge_rmse, 4))


# ============================================================
# 13. MODEL COMPARISON
# ============================================================

print("\n========================================")
print("MODEL COMPARISON")
print("========================================")


comparison = pd.DataFrame({

    "Model": [
        "Linear Regression",
        "Ridge Regression"
    ],

    "R2 Score": [
        r2,
        ridge_r2
    ],

    "MSE": [
        mse,
        ridge_mse
    ],

    "RMSE": [
        rmse,
        ridge_rmse
    ]

})


print(
    comparison.round(4)
)


# Save model comparison and trained model for submission
comparison.to_csv(BASE_DIR / "Reports" / "model_comparison.csv", index=False)
try:
    import joblib
    joblib.dump(model, BASE_DIR / "Model" / "student_performance_model.pkl")
except Exception as save_error:
    print("Could not save model:", save_error)
# ==========================================
# UNIQUE FEATURE: FEATURE IMPACT ANALYSIS
# ==========================================

print("\n===== FEATURE IMPACT ANALYSIS =====")

feature_impact = pd.DataFrame({
    "Feature": features,
    "Impact": model.coef_
})

feature_impact["Absolute_Impact"] = feature_impact["Impact"].abs()
feature_impact = feature_impact.sort_values(
    "Absolute_Impact", ascending=False
)

print(feature_impact[["Feature", "Impact"]])

# Feature Impact Graph
plt.figure(figsize=(9, 5))
plt.bar(
    feature_impact["Feature"],
    feature_impact["Impact"]
)

plt.axhline(0, linewidth=1)
plt.xlabel("Features")
plt.ylabel("Linear Regression Coefficient")
plt.title("Feature Impact on Student Final Score")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig(BASE_DIR / "Graphs" / "feature_impact.png", dpi=150, bbox_inches="tight")
plt.close()

print(
    "\nMost influential feature:",
    feature_impact.iloc[0]["Feature"]
)

# ============================================================
# 14. FINAL RESULTS
# ============================================================

print("\n========================================")
print("FINAL RESULTS")
print("========================================")


print(
    "\nLinear Regression R2:",
    round(r2, 4)
)

print(
    "Linear Regression RMSE:",
    round(rmse, 4)
)

print(
    "Ridge Regression R2:",
    round(ridge_r2, 4)
)

print(
    "Ridge Regression RMSE:",
    round(ridge_rmse, 4)
)


# ============================================================
# 15. CONCLUSION
# ============================================================

print("\n========================================")
print("CONCLUSION")
print("========================================")


print(
    "\nStudent Performance Prediction model"
)

print(
    "was successfully developed using"
)

print(
    "Machine Learning."
)

print(
    "\nLinear Regression and Ridge Regression"
)

print(
    "were used to predict the Final Score."
)

print(
    "\nModel performance was evaluated using"
)

print(
    "R2 Score, MSE and RMSE."
)


# ============================================================
# 16. FUTURE SCOPE
# ============================================================

print("\n========================================")
print("FUTURE SCOPE")
print("========================================")


print(
    "\nFuture improvements can include:"
)

print(
    "1. Using a larger real-world dataset."
)

print(
    "2. Using additional student features."
)

print(
    "3. Trying advanced Machine Learning models."
)

print(
    "4. Creating a web application for prediction."
)

print(
    "5. Adding a graphical user interface."
)

# ==============================
# UNIQUE FEATURE: STUDENT PREDICTION
# ==============================

print("\n===== STUDENT PERFORMANCE PREDICTION =====")

try:
    study_hours = float(input("Enter Study Hours: "))
    attendance = float(input("Enter Attendance (%): "))
    previous_score = float(input("Enter Previous Score: "))
    assignment_score = float(input("Enter Assignment Score: "))
    
    activity = input("Extracurricular Activity (Yes/No): ").strip().lower()
    activity_value = 1 if activity == "yes" else 0
    
    sleep_hours = float(input("Enter Sleep Hours: "))

    student_data = pd.DataFrame([[
        study_hours,
        attendance,
        previous_score,
        assignment_score,
        activity_value,
        sleep_hours
    ]], columns=features)

    predicted_score = model.predict(student_data)[0]
    predicted_score = np.clip(predicted_score, 0, 100)

    if predicted_score >= 75:
        category = "Excellent"
    elif predicted_score >= 50:
        category = "Good"
    else:
        category = "Needs Improvement"

    print("\n===== PREDICTION RESULT =====")
    print("Predicted Final Score:", round(predicted_score, 2))
    print("Performance Category:", category)

    # Prediction Graph
    plt.figure(figsize=(7, 5))
    plt.bar(["Predicted Score"], [predicted_score])
    plt.ylim(0, 100)
    plt.ylabel("Score")
    plt.title("Student Final Score Prediction")
    plt.savefig(BASE_DIR / "Graphs" / "prediction_result.png", dpi=150, bbox_inches="tight")
    plt.close()

except (ValueError, EOFError):
    print("Prediction input skipped. Run the script in a terminal to enter a student profile.")

# ============================================================
# PROJECT COMPLETED
# ============================================================

print("\n========================================")
print("PROJECT COMPLETED SUCCESSFULLY!")
print("========================================")
