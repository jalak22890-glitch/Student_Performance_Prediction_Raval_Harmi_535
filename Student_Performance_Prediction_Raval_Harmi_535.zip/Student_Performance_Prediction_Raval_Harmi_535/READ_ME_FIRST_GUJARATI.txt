Harmi, aa taro Student Performance Prediction project chhe.

1. ZIP ne Extract All kar.
2. VS Code ma extracted folder open kar.
3. Terminal ma: python -m pip install -r requirements.txt
4. Pachhi: python "Code/all code.py"
5. Program input mange tyare student ni details nakh.

Folder structure badalti nahi. Taro naam: Raval Harmi | Roll No: 535
